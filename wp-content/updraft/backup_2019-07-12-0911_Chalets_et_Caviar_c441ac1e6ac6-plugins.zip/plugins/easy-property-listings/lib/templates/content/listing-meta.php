<?php
/*
 * This file is depricated and will be removed in future.
 *
 * It is advised to follow the updated documentation for the alternatives for the current version of plugin
 *
 * @package     EPL
 * @subpackage  Templates/Content
 * @copyright   Copyright (c) 2019, Merv Barrett
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 * @deprecated deprecated since version 1.3
 */

include(EPL_COMPATABILITY . 'listing-meta-compat.php' );

